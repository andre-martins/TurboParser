from .python.ad3 import *
from .python.simple_inference import simple_grid, general_graph
